# Glossary (the caveman dictionary, human side)

The quick meanings. Every word has a full page in [All words A-Z](words.html).

## Doing words (statements)

| Word | Say it like | Meaning |
| --- | --- | --- |
| `oga` | OH-gah | print / say |
| `grunk` | GRUNK | make a box (variable) |
| `binga` | BING-ah | if |
| `wonga` | WONG-ah | else |
| `unga` | OON-gah | end of a block |
| `booga` | BOO-gah | repeat N times |
| `zug` | ZUG | while |
| `zoop` | ZOOP | for each thing in a pile |
| `clump` | KLUMP | function definition |
| `ork` | ORK | return an answer |
| `blorp` | BLORP | ask the person a question |
| `skrib` | SKRIB | draw |
| `ugg` | UGG | comment / note |

## Helper words

| Word | Meaning |
| --- | --- |
| `snorf` | make a pile (list) |
| `plop` | nothing; `plop(pile, x)` adds x |
| `nom` | count (length) |
| `skoop` | get a thing by spot number |
| `yoink` | remove the last thing |
| `goop` | turn something into text |
| `shout` / `whisper` | uppercase / lowercase |
| `flip` | reverse text |
| `find` | where does a piece start? |
| `split` / `join` | text to pile / pile to text |
| `what` | what kind of thing is this? |
| `numba` | text to number |
| `munga` | random number |
| `round` / `flat` / `roof` | nearest / down / up |
| `abs` | distance from zero |
| `small` / `big` | smaller / bigger of two |
| `root` / `pow` | square root / power |
| `wait` | pause (milliseconds) |

## Values

| Word | Meaning |
| --- | --- |
| `gronk` | yes / true |
| `nork` | no / false |
| `plop` | nothing |
| `pi` | 3.14159... |
| `lap` | which loop lap (magic box) |

## Kinds of things

| CMC name | Human name |
| --- | --- |
| number | integer or decimal |
| goop | text / string |
| truth | boolean |
| pile | list / array |
| plop | nothing / null |
| clump | function |
| box | variable |

## Ideas

| Word | Meaning |
| --- | --- |
| block | the code between a starter word and `unga` |
| slot | a little box in the block editor where an expression goes |
| expression | anything that makes a value: `2 + 3`, `"hi"`, `x` |
| recursion | a clump calling itself |
| OOGA | a friendly error message |

Next: [Roadmap](roadmap.md).