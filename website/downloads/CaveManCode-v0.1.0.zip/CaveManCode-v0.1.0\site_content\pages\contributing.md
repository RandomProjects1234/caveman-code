# Contributing

Welcome, cave artist. There are many ways to help, and most need no code at
all.

## Ways to help

### Tell a story or report a bump

Open a GitHub issue that says what you tried, what you expected, and what
happened. Tiny programs are perfect bug reports:

```cmc
ugg bug: oga with three things in a binga block
grunk x = 1
binga x == 1
    oga "one", x, "!"
unga
```

### Write examples

The examples folder is the heart of the project. New examples should:

- do one fun thing
- be readable by a beginner
- come with a `.out` file showing the exact output
- have a short note at the top in an `ugg` line

A test runs every example and compares the output, so your `.out` must match
exactly.

### Improve the dictionary

Every word lives in `src/cmc/words.py`. A good entry has:

- a one-line summary
- the syntax, with `<things>` in angle brackets
- a warm explanation with an example
- tips about the mistakes people actually make

### Translate

The dictionary, the cheat sheet, and the tutorial are the best things to
translate first. Keep the CMC words themselves; translate the explanations.

### Teach

Classroom materials, posters, wall charts, and videos are all welcome. Tell
us how it went -- "the 6 year olds loved `skrib` but got stuck on X" is
valuable design feedback.

### Write code

- Bugs with tests are the fastest to accept.
- Big features should start as an issue with a sketch of the design.
- Keep the language small: new keywords need a very good reason.
- Every error message needs a friendly hint. That is the house style.

## House style

- **Kindness first.** Errors, docs, and messages should make a beginner feel
  capable.
- **One idea per line.** In code and in explanations.
- **Explain WHY.** Comments and docs explain reasons, not mechanics.
- **Test everything.** `powershell -File native\tests\run_tests.ps1` must pass.
- **No new dependencies.** CMC is plain C++ (C++17) install. Pull requests
  that add packages will be asked to remove them.

## The setup

```text
git clone https://github.com/your-name/caveman-code
cd caveman-code
set PYTHONPATH=src
bin\cmc.exe run examples/01_hello_oga.cmc
bin\ogabooga.exe
powershell -File native\tests\run_tests.ps1
```

To rebuild the website:

```text
python tools/build_site.py --check
```

## Pull request checklist

- [ ] Tests pass
- [ ] New behavior has tests
- [ ] Error messages have hints
- [ ] Docs updated (README, docs/, site_content/) if users see a change
- [ ] Examples still pass
- [ ] The diff is small and focused

## The code, cave by cave

| Folder | What lives there |
| --- | --- |
| `src/cmc/lexer.py` | turns text into tokens |
| `src/cmc/parser.py` | turns tokens into a tree |
| `src/cmc/interpreter.py` | runs the tree |
| `src/cmc/builtins.py` | helper words |
| `src/cmc/codegen.py` | CMC to Python |
| `src/cmc/words.py` | the dictionary (docs + aliases) |
| `src/ogabooga/` | the IDE |
| `examples/` | example programs and expected outputs |
| `tests/` | the test suite |
| `site_content/` | the website words, built by `tools/build_site.py` |

Thank you for helping the next cave coder.

Next: [Publishing guide](publishing.md).