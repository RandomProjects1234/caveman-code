# The 30 minute tutorial

Welcome! In half an hour you will know the whole language. Do not rush --
type every example yourself and press RUN. Mistakes are part of the game.

If you have not installed CMC yet, see [Installing CMC](install.md).

## Minute 0-2: Talking

```cmc
oga "Ooga booga!"
```

`oga` says things. Text lives in quotes. You can say several things in one go;
CMC puts a space between them:

```cmc
oga "Ugg", "has", 3, "rocks"
```

```text
Ugg has 3 rocks
```

Notes start with `ugg` and reach the end of the line:

```cmc
ugg this whole line is a note
oga "hello"   ugg this part is a note
```

## Minute 2-6: Boxes (variables)

```cmc
grunk name = "Ugg"
grunk age = 4

oga name, "is", age
```

`grunk` makes a **box**. To change a box you already made, just use `=`:

```cmc
age = age + 1
oga name, "is now", age
```

Box names can have letters, numbers, and `_`, and cannot start with a number.
You cannot name a box after a CMC word like `nom` or `unga`.

Magic boxes you did not make:

| Box | Holds |
| --- | --- |
| `gronk` | yes / true |
| `nork` | no / false |
| `plop` | nothing at all |
| `pi` | 3.14159... |
| `lap` | which lap of a `booga` loop you are on |

## Minute 6-10: Math and text

```cmc
oga 2 + 3        ugg 5
oga 10 - 4       ugg 6
oga 6 * 7        ugg 42
oga 9 / 3        ugg 3     (whole when it fits!)
oga 10 / 4       ugg 2.5
oga 10 % 3       ugg 1     (the remainder)
```

Math helpers:

```cmc
oga round(2.6)   ugg 3
oga flat(2.9)    ugg 2
oga roof(2.1)    ugg 3
oga abs(0 - 7)   ugg 7
oga big(3, 9)    ugg 9
oga small(3, 9)  ugg 3
oga root(81)     ugg 9
oga pow(2, 5)    ugg 32
oga munga(1, 6)  ugg surprise! a random number
```

Text sticks together with `+`, and `goop` turns other things into text:

```cmc
grunk rocks = 7
oga "I have " + goop(rocks) + " rocks"
oga shout("hello")     ugg HELLO
oga whisper("QUIET")   ugg quiet
oga flip("booga")      ugg agoob
oga nom("cave")        ugg 4, how many letters
```

## Minute 10-14: Choices

```cmc
grunk rocks = 5

binga rocks > 3
    oga "Lots of rocks!"
wonga
    oga "Not many rocks."
unga
```

- `binga` = if
- `wonga` = else
- `unga` = the block ends here

Checks you can use: `==`, `!=`, `<`, `<=`, `>`, `>=`.
Join checks with `and`, `or`, `not`:

```cmc
binga rocks > 2 and rocks < 10
    oga "A nice pile."
unga
```

`wonga binga` means "else if":

```cmc
binga rocks > 9
    oga "huge!"
wonga binga rocks > 4
    oga "medium!"
wonga
    oga "small!"
unga
```

## Minute 14-18: Loops

`booga` repeats a set number of times. `lap` tells you which time it is:

```cmc
booga 3
    oga "lap", lap
unga
```

`zug` repeats while a check stays gronk:

```cmc
grunk fuel = 3
zug fuel > 0
    oga "zoom! fuel:", fuel
    fuel = fuel - 1
unga
oga "out of fuel"
```

`zoop` walks through a pile (list) or the letters of text:

```cmc
grunk pets = snorf("dog", "cat", "rock")
zoop pet in pets
    oga "I love my", pet
unga
```

```cmc
zoop letter in "cave"
    oga letter
unga
```

If a `zug` loop never stops, CMC stops it for you and says
*"This program ran for a very long time."*

## Minute 18-23: Clumps (your own words)

A `clump` is a piece of code with a name.

```cmc
clump greet(name)
    oga "Hello " + name + "!"
unga

greet("Ugg")
greet("Oona")
```

Use `ork` to give an answer back:

```cmc
clump double(n)
    ork n * 2
unga

oga double(21)
```

A clump can call itself. That is called **recursion**:

```cmc
clump countdown(n)
    binga n > 0
        oga n
        countdown(n - 1)
    unga
unga

countdown(5)
```

## Minute 23-27: Piles (lists)

A pile holds many things in order.

```cmc
grunk bag = snorf()
plop(bag, "apple")
plop(bag, "rock")
plop(bag, "banana")

oga bag              ugg [apple, rock, banana]
oga nom(bag)         ugg 3
oga bag[0]           ugg apple
oga bag[-1]          ugg banana
oga skoop(bag, 1)    ugg rock

grunk last = yoink(bag)
oga "yoinked", last
oga bag              ugg [apple, rock]

bag[0] = "golden apple"
oga bag
```

- `snorf(...)` makes a pile
- `plop(pile, thing)` adds to the end
- `nom(pile)` counts
- `yoink(pile)` takes the last thing off
- spot numbers start at **0**, and `-1` is the last spot
- `"cat" in pets` asks if something is inside

## Minute 27-30: Drawing and asking

```cmc
skrib size 400, 400
skrib color "red"
skrib dot 200, 200, 20
grunk who = blorp "Who is there?"
skrib write who, 150, 250
oga "drew", who
```

- `skrib` draws in the Draw tab (or a window in the terminal)
- `blorp` asks the person a question; the answer comes back as text
- `numba(answer)` turns text into a number so you can do math with it

## You know CMC now

The rest is practice. Try these:

1. Make a clump `double` and print doubles from 1 to 10 with `booga`.
2. Make a pile of your favorite foods and `zoop` over it.
3. Write a guessing game with `munga(1, 10)`, `blorp`, and `numba`.
4. Draw a house with `skrib blob` and `skrib box`.
5. Read [All the words A-Z](words.html) and find a word you have not used.

When you are ready for the next level, read the
[Style guide](style-guide.md) to learn how to write CMC like a wise old
cave painter.