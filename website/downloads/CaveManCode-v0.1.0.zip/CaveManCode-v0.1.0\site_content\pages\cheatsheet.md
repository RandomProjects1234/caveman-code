# Cheat sheet

One page with everything. Print it, tape it to the cave wall.

## Talking

| Write this | It does |
| --- | --- |
| `oga <things>, <things>` | print on one line |
| `blorp "question"` | ask the person, answer comes back as text |
| `ugg anything` | a note, ignored by the computer |

## Boxes

| Write this | It does |
| --- | --- |
| `grunk x = 5` | make a new box |
| `x = 6` | change an existing box |
| `x = x + 1` | change it using its old value |
| `gronk` / `nork` | yes / no |
| `plop` | nothing |
| `pi` | 3.14159... |
| `lap` | which `booga` lap you are on (magic) |

## Choices

```cmc
binga check
    ...
wonga
    ...
unga
```

```cmc
binga check
    ...
wonga binga other_check
    ...
wonga
    ...
unga
```

## Logic

`and` &nbsp; `or` &nbsp; `not` &nbsp; `==` &nbsp; `!=` &nbsp; `<` &nbsp; `<=` &nbsp; `>` &nbsp; `>=` &nbsp; `in` &nbsp; `not in`

## Loops

| Write this | It does |
| --- | --- |
| `booga 5` ... `unga` | do it 5 times, `lap` counts 1..5 |
| `zug x < 10` ... `unga` | while the check is gronk |
| `zoop thing in pile` ... `unga` | once per thing in a pile or text |

## Clumps (functions)

```cmc
clump name(a, b)
    oga a
    ork a + b
unga

oga name(1, 2)
```

## Piles (lists)

| Write this | It does |
| --- | --- |
| `snorf(1, 2, 3)` | make a pile |
| `snorf()` | empty pile |
| `plop(pile, x)` | add x to the end |
| `nom(x)` | how many |
| `pile[0]` | first thing (spots start at 0) |
| `pile[-1]` | last thing |
| `skoop(pile, 2)` | same as `pile[2]` |
| `yoink(pile)` | take the last thing off |
| `pile[1] = 9` | change a spot |
| `x in pile` | is x inside? |

## Text

`shout(t)` `whisper(t)` `flip(t)` `find(t, piece)` `split(t, sep)` `join(pile, sep)` `goop(x)` `nom(t)` `skoop(t, i)` `t[i]`

## Numbers

`round(x)` `flat(x)` `roof(x)` `abs(x)` `small(a,b)` `big(a,b)` `root(x)` `pow(a,b)` `munga(a,b)` `numba(text)`

## Drawing

| Write this | It does |
| --- | --- |
| `skrib size 400, 400` | set picture size |
| `skrib color "red"` | pick a color (names or `"#ff8800"`) |
| `skrib dot x, y, r` | filled circle |
| `skrib circle x, y, r` | outline circle |
| `skrib line x1, y1, x2, y2` | a line |
| `skrib box x, y, w, h` | outline rectangle |
| `skrib blob x, y, w, h` | filled rectangle |
| `skrib write "words", x, y` | text on the picture |
| `skrib clear` | wipe the picture |
| `wait(500)` | pause half a second |

The spot `0, 0` is the top-left corner.

## English mode

Every CMC word has an English twin you can mix in freely:

| CMC | English |
| --- | --- |
| oga | print, say |
| grunk | let, make |
| binga | if |
| wonga | else |
| unga | end, done, finish |
| booga | repeat |
| zug | while |
| zoop | for |
| clump | fn, function, def |
| ork | return, give |
| blorp | ask |
| skrib | draw |
| ugg | comment |
| gronk | true |
| nork | false |
| plop | nothing |

## The shape of a program

```cmc
ugg notes at the top
grunk boxes...
clump helpers...
ugg the actual work
booga / binga / zoop blocks
oga answers
```

## Terminal commands

```text
cmc                     talk to CMC (REPL)
cmc run hello.cmc       run a program
cmc compile hello.cmc   make hello.py
cmc init hello.cmc      make a starter program
cmc examples            list example programs
```

## OGABOOGA CODER keys

`F5` run &nbsp; `Esc` stop &nbsp; `Ctrl+S` save &nbsp; `Ctrl+O` open &nbsp; `Ctrl+N` new &nbsp; `Ctrl+Z` undo blocks